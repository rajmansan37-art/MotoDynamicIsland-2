package com.example.motodynamicisland

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable

class IslandService : Service() {
    private lateinit var windowManager: WindowManager
    private var island: LinearLayout? = null
    private var expanded = false
    private var batteryPercent = -1
    private var charging = false
    private var receiverRegistered = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != Intent.ACTION_BATTERY_CHANGED) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPercent = if (level >= 0) (level * 100 / scale) else -1
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            render()
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        receiverRegistered = true
        render()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(9), dp(16), dp(9))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.rgb(48, 48, 48))
            }
            elevation = dp(12).toFloat()
            isClickable = true
            setOnClickListener {
                expanded = !expanded
                render()
            }
        }
        val headline = TextView(this).apply {
            text = if (charging) "⚡  Charging  •  ${batteryPercent.coerceAtLeast(0)}%" else "●  Dynamic Island"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(headline, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (expanded) {
            val detail = TextView(this).apply {
                text = "MOTO DYNAMIC ISLAND\nBattery: ${if (batteryPercent >= 0) "$batteryPercent%" else "Checking…"}\nTap to close"
                setTextColor(Color.LTGRAY)
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            }
            root.addView(detail)
        }

        val params = WindowManager.LayoutParams(
            if (expanded) dp(230) else dp(174),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = dp(12)
            y = dp(12)
        }

        try {
            if (island == null) {
                island = root
                windowManager.addView(root, params)
            } else {
                val old = island!!
                windowManager.removeView(old)
                island = root
                windowManager.addView(root, params)
            }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        try { island?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        island = null
        if (receiverRegistered) {
            try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
