# Moto Dynamic Island

A small Android Studio starter project for a top-left, iPhone-inspired floating pill on the Motorola Pad 60 Neo (Android 16).

## Current features
- Floating black pill overlay at the top-left.
- Tap to expand/collapse.
- Live battery percentage and charging state.
- Start/stop controls in the app.

## Build a free APK
1. Install Android Studio (free) on a computer.
2. Open this `MotoDynamicIsland` folder in Android Studio.
3. Allow Gradle sync to finish and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to the tablet and install it. If Android asks, allow installation from that file manager/browser.

## First launch on the tablet
1. Open Moto Dynamic Island.
2. Tap **Grant overlay permission** and enable **Display over other apps**.
3. Return to the app and tap **Start Dynamic Island**.

## Notes
- The app intentionally starts only after you tap Start.
- This starter build does not yet read notification contents or control music. Those require additional notification-listener/media-session work and separate user-granted access.
- Android 16 may show permission or background-service warnings depending on Motorola software. If the overlay is stopped by battery management, allow the app to run without battery optimization restrictions in system settings.
- This is an independent Android project, not an official Apple or Motorola product.
